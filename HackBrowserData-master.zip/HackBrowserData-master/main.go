package main

import (
	"hack-browser-data/cmd"
)

func main() {
	cmd.Execute()
}
